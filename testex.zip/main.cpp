#include <QWebEngineView>
#include <QtGui/QtGui>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QApplication>
#include <QMediaPlayer>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QVideoWidget>
#include <QVBoxLayout>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Ui::MainWindow window_ui;
    window_ui.setupUi(&w);
    QVBoxLayout* v_layout = window_ui.verticalLayout;
    w.resize(640, 600);
    w.setWindowTitle("TESTEX.");
    w.setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    QWebEngineView new_web_view (&w);
    v_layout -> addWidget(&new_web_view);
    new_web_view.resize(640, 200);
    new_web_view.load(QUrl("qrc:/index.html"));
    new_web_view.setStyleSheet("background-color:#000000;"
                  "color: #ffffff;");

    //
    QMediaPlayer player (&w);
    QAudioOutput audio_out;
    QWidget video (&w);
    video.resize(640, 280);
    QVideoWidget video_widget (&video);
    v_layout -> addWidget(&video);

    video_widget.resize(640, 280);
    player.setAudioOutput(&audio_out);
    player.setVideoOutput(&video_widget);
    player.setSource(QUrl("qrc:/sample-5s.mp4"));
    player.play();
    QObject::connect(&player, &QMediaPlayer::playingChanged, &player, &QMediaPlayer::play);
    w.show();
    return a.exec();
}
